﻿using Abp.Application.Services;
using Logger.MultiTenancy.Dto;

namespace Logger.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

